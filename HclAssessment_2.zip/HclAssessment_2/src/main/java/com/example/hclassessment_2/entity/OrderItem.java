package com.example.hclassessment_2.entity;


import jakarta.persistence.Entity;

@Entity
public class OrderItem {

    private long orderItemId;
    private CustomerOrder customerOrder;
    private Product product;
    private int quantity;
    private double price;

    public OrderItem(long orderItemId, CustomerOrder customerOrder, Product product, int quantity, double price) {
        this.orderItemId = orderItemId;
        this.customerOrder = customerOrder;
        this.product = product;
        this.quantity = quantity;
        this.price = price;
    }


    public long getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(long orderItemId) {
        this.orderItemId = orderItemId;
    }

    public CustomerOrder getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(CustomerOrder customerOrder) {
        this.customerOrder = customerOrder;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
