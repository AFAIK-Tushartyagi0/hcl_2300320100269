package com.example.hclassessment_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HclAssessment2Application {

    public static void main(String[] args) {
        SpringApplication.run(HclAssessment2Application.class, args);
    }

}
