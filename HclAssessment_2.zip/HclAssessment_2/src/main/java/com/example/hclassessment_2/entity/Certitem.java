package com.example.hclassessment_2.entity;

import jakarta.persistence.Entity;

@Entity
public class Certitem {

    private long cartItemid;
    private Cart cart;
    private Product product;
    private int quantity;
    private double price;

    public Certitem(long cartItemid, Cart cart, Product product, int quantity, double price) {
        this.cartItemid = cartItemid;
        this.cart = cart;
        this.product = product;
        this.quantity = quantity;
        this.price = price;
    }

    public long getCartItemid() {
        return cartItemid;
    }

    public void setCartItemid(long cartItemid) {
        this.cartItemid = cartItemid;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
