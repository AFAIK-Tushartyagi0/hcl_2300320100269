package com.example.hclassessment_2.entity;


import jakarta.persistence.Entity;

@Entity
public class Customer {
    private long customerid;
    private String CustomerName;
    private String email;
    private String password;
    private String mobile;
    private String city;

    public Customer(long customerid, String customerName, String email, String password, String mobile, String city) {
        this.customerid = customerid;
        CustomerName = customerName;
        this.email = email;
        this.password = password;
        this.mobile = mobile;
        this.city = city;
    }

    public long getCustomerid() {
        return customerid;
    }

    public void setCustomerid(long customerid) {
        this.customerid = customerid;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
