package com.example.hclassessment_2.entity;

import jakarta.persistence.Entity;

import java.time.LocalDate;

@Entity
public class Cart {
    private long cartid;
    private Customer customer;
    private LocalDate createdate;

    public Cart(long cartid, LocalDate createdate, Customer customer) {
        this.cartid = cartid;
        this.createdate = createdate;
        this.customer = customer;
    }

    public long getCartid() {
        return cartid;
    }

    public void setCartid(long cartid) {
        this.cartid = cartid;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDate getCreatedate() {
        return createdate;
    }

    public void setCreatedate(LocalDate createdate) {
        this.createdate = createdate;
    }
}
